import React from 'react';  
// import Card from './Card';  
// import './index.css'
// import InvoiceCalc from './invoiceCalc';
// import TicTacToe from './ticTac'; 
// import ToDoList from './todolist';
// import ReadMore from './readMore';
// import BudgetManege from './budgetManege';
import Color from './color';

function App() {
  return (
    <div >
      <Color/>
    </div>
  );
}


export default App;



